package com.example.android.coursera.mydailyselfie;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created on 8/11/2017.
 * This class implements the adapter that contains images for the gridview layout.
 *
 * It maintains two arrays. The first is of the images (so that they don't need to be reloaded) and
 * the second is the path to each image file.
 */

public class ImageThumbnailAdapter extends BaseAdapter {
    private static final int PADDING = 24;
    private static final int WIDTH = 250;
    private static final int HEIGHT = 250;
    private Context mContext;
    private ArrayList<Bitmap> mThumbBitmaps;
    private ArrayList<String> mThumbPaths;

    // Store the list of image IDs
    public ImageThumbnailAdapter(Context c, ArrayList<Bitmap> bitmaps,
                                 ArrayList<String> paths) {
        mContext = c;
        this.mThumbBitmaps = bitmaps;
        this.mThumbPaths = paths;
    }

    // Return the number of items in the Adapter
    @Override
    public int getCount() {
        return mThumbBitmaps.size();
    }

    // Return the data item at position
    @Override
    public Object getItem(int position) {
        return mThumbBitmaps.get(position);
    }

    // Will get called to provide the ID that
    // is passed to OnItemClickListener.onItemClick()
    @Override
    public long getItemId(int position) {
        return position;
    }

    // Return an ImageView for each item referenced by the Adapter
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ImageView imageView = (ImageView) convertView;

        // if convertView's not recycled, initialize some attributes
        if (imageView == null) {
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(WIDTH, HEIGHT));
            imageView.setPadding(PADDING, PADDING, PADDING, PADDING);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        }

        imageView.setImageBitmap(mThumbBitmaps.get(position));
        return imageView;
    }

    public void add(Bitmap b, String path)
    {
        mThumbBitmaps.add(b);
        mThumbPaths.add(path);
    }

    public String getPath(int position)
    {
        return mThumbPaths.get(position);
    }

    public void clear()
    {
        mThumbPaths.clear();
        mThumbBitmaps.clear();
    }

}
