package com.example.android.coursera.mydailyselfie;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.*;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static android.support.v7.appcompat.R.styleable.MenuItem;

public class MainActivity extends AppCompatActivity {

    //Declare member variables
    private String mCurrentPhotoPath;
    private Button mButton;
    private GridView mGridView;
    private ImageThumbnailAdapter mAdapter;
    private String mNewImagePath = null;
    private AlarmManager mAlarmManager = null;
    private Intent mNotificationReceiverIntent;
    private PendingIntent mNotificationReceiverPendingIntent;

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final long TWO_MIN = 2 * 60 * 1000L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //The OnCreate method is responsible for
        //1. Loading and stored images on the external device, placing them into the
        //    "ImageThumbnailAdapter". (A future upgrade would be to delegating the loading
        //     to an AsyncTask).
        //2. Initialize the GridView, as defined in the "activity_mail.xml" layout, with the loaded
        //   images.
        //3. Set the onTouch response of the GridView to pass the path name of the selected image
        //     to the "ImageViewActivity" to display.
        //4. Setup a recurring alarm (every 2 min) and associated notification

        //Identify any existing images in external storage and add the images and paths to the
        //array list. These will be used to initialize the adapter
        ArrayList<Bitmap> bitmaps = new ArrayList<Bitmap>();
        ArrayList<String> paths = new ArrayList<String>();

        //Check the application directory for images. This part should be delegatd to an AsyncTask
        //so that it doesn't delay startup. However, for this example, we'll leave it here
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        String files[] = storageDir.list();
        //Load bitmaps into list
        for(int j=0;j<files.length;j++) {
            String path = storageDir+"/"+files[j];
           Bitmap bMap = BitmapFactory.decodeFile(path);
           bitmaps.add(bMap);
            paths.add(path);
        }

        //Setup the GridView and initialize the Adapter with existing images
        mAdapter = new ImageThumbnailAdapter(getApplicationContext(), bitmaps, paths);
        mGridView = (GridView)findViewById(R.id.gridview);
        mGridView.setAdapter(mAdapter);

        //Define Touch response. Will launch the ImageViewActivity. The path of the image file to
        //display is passed via the extra data in the Intent
        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Intent image_view_intent = new Intent(getApplicationContext(),ImageViewActivity.class);
                image_view_intent.putExtra("BitmapFileName", mAdapter.getPath(position));
                startActivity(image_view_intent);
            }
        });

        //Setup the reminder Alarm and Notification
        mNotificationReceiverIntent = new Intent(MainActivity.this,
                AlarmNotificationReceiver.class);

        // Create an PendingIntent that holds the NotificationReceiverIntent
        mNotificationReceiverPendingIntent = PendingIntent.getBroadcast(
                MainActivity.this, 0, mNotificationReceiverIntent, 0);

        mAlarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        mAlarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + TWO_MIN,
                TWO_MIN,
                mNotificationReceiverPendingIntent);

    }

    //Setup the camera icon and trash icon in the actionbar to be used to command a picture or
    //to delete all of the images
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_menu, menu);
        return true;
    }

    //There are two icons in the action bar that require handling
    //camera icon ("id.action_picture") will launch the camera and retrieve a picture. Once the
    //   picture is taken, the result will activate the "onActivityResult" callback defined below
    //   which will save the picture to external storage and add an entry to the adapter for the
    //   GridView
    //
    //trash icon ("id.action_trash") will clear the adapter for the GridView (removing all the
    //   images). It will also delete all the picture files in external storage
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // action with ID action_refresh was selected
            case R.id.action_picture:
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    // Create the File where the photo should go
                    File photoFile = null;
                    try {
                        photoFile = createImageFile();
                    } catch (IOException ex) {
                        Toast t = Toast.makeText(getApplicationContext(),"Error Saving File", Toast.LENGTH_SHORT);
                        t.show();
                    }
                    // Continue only if the File was successfully created
                    if (photoFile != null) {
                        Uri photoURI = FileProvider.getUriForFile(this,
                                "com.example.android.fileprovider",
                                photoFile);
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);

                        mNewImagePath = photoURI.getPath();
                    }
                }
                break;

            case R.id.action_trash:
                //Delete all the inputs and files
                mAdapter.clear();
                mAdapter.notifyDataSetChanged();
                Toast.makeText(getApplicationContext(),"Deleting all Image Files",Toast.LENGTH_SHORT).show();
                File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                String files[] = storageDir.list();
                //Delete Files
                for(int j=0;j<files.length;j++) {
                    File file = new File(storageDir,files[j]);
                    file.delete();
                }
                break;

            default:
                break;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            //Load and add to the adapter
            Bitmap bmp = BitmapFactory.decodeFile(mCurrentPhotoPath);
            if(bmp != null) {
                mAdapter.add(bmp, mCurrentPhotoPath);
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    //Utility function to create an output file for a new image
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }
}

