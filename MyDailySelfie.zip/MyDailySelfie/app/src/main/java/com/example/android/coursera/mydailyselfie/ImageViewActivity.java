package com.example.android.coursera.mydailyselfie;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

//This activity displays an entire image.
//The path to the image is passed in as a string through the Intent

public class ImageViewActivity extends AppCompatActivity {

    public Bitmap mBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_view);

        //Retrieve the bitmap filename
        Intent in = getIntent();
        String filename = in.getStringExtra("BitmapFileName");
        Bitmap bmp = BitmapFactory.decodeFile(filename);

        if(bmp!=null) {
            ImageView iv = (ImageView) findViewById(R.id.image_view_image);
            iv.setImageBitmap(bmp);
        }
    }
}
